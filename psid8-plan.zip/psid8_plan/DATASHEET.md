# PSID-8 (video) — Datasheet and Release Checklist

Complete this document **as the corpus is built**, not after. Every `[PENDING]`
below is a decision or a measurement that must exist before release; shipping
with any of them unfilled means shipping a claim you cannot support.

The structure follows the datasheets-for-datasets convention: motivation,
composition, collection, preprocessing, uses, distribution, maintenance.

---

## 1. Motivation

**Why does this dataset exist?**
Physical-security incident detection is limited by data, not by architecture. The
accompanying paper (*Towards Physical Security Incident Detection in Video
Surveillance: The SENTRY Architecture and the Data Gap*) shows this empirically:
a temporal reasoning module trained on the data public corpora afford (78 clips,
one class, four cameras) memorizes rather than generalizes; open-vocabulary
detection with compositional prompts beats class names ~7× but stays at low
absolute performance; and `intrusion` is unrecoverable from appearance alone
(F1 = 0.000 in every prompt condition). No public corpus provides the eight
incident classes with spatiotemporal annotation on real surveillance footage.
PSID-8 exists to close that gap.

**Who funded it?** [PENDING]

---

## 2. Composition

**What do the instances represent?**
Short surveillance video clips (default 10 s), re-annotated from public source
corpora, with frame-level bounding boxes linked into events by `event_id`, plus
four compositional attributes per event (object, action, environment, context)
and, where applicable, restricted-zone polygons.

| Field | Value |
|---|---|
| Number of clips | [PENDING] |
| Positive clips (≥1 incident) | [PENDING] |
| Negative clips | [PENDING] |
| — of which **hard negatives** | [PENDING] |
| Clips per class | [PENDING — per class] |
| Distinct cameras | [PENDING] |
| Distinct scenes | [PENDING] |
| Total annotated frames | [PENDING] |
| Total event instances | [PENDING] |

**Classes.** accident, suspicious_behavior, crime, fire, intrusion,
suspicious_object, fall, vandalism (canonical ids 0–7, unchanged from the
schema).

**Is any class under-represented or absent?**
State this explicitly and prominently. `suspicious_behavior` has no dedicated
public source and is expected to be the weakest class of v1: [PENDING — final
count and the honest caveat]. A class with too few clips is reported as such,
never quietly padded.

**Are there hard negatives, and of what kind?**
Yes, deliberately collected and tagged: `lying_no_transition`, `benign_smoke`,
`authorized_entry`, `waiting`, `brief_object`, `horseplay`, `running_benign`.
Counts: [PENDING]. A benchmark without hard negatives measures detection of the
obvious; these are what make it measure discrimination.

**Multi-label / co-occurrence.** Clips may carry more than one class (e.g. a fall
during an accident). Co-occurrence counts: [PENDING].

---

## 3. Collection

**Sources.** Clips are extracted from public corpora and re-annotated. For each
source, record: name, version/mirror, license, URL, and how many clips came from
it.

| Source | License | Clips | Classes contributed |
|---|---|---|---|
| UCF-Crime | [PENDING] | [PENDING] | crime, accident, intrusion, vandalism, fire |
| Le2i | [PENDING] | [PENDING] | fall |
| [others] | [PENDING] | [PENDING] | [PENDING] |

**Source labels are hints, not ground truth.** The source corpus's class is
recorded as `source_class` and used only to locate candidate clips. Every label
in PSID-8 comes from our own annotation under `VIDEO_ANNOTATION_GUIDE.md`. An
annotator may find no event where the source claimed one; that clip becomes a
negative.

**Who annotated, and how were they trained?**
[PENDING — number of annotators, their training, the calibration rounds they
passed. See CALIBRATION_PROTOCOL.md.]

**Annotation quality (the headline numbers of this dataset):**

| Metric | Gate | Result |
|---|---|---|
| Double-annotated fraction | ≥ 20% | [PENDING] |
| Cohen's kappa, per class | ≥ 0.70 | [PENDING — per class] |
| Mean IoU of matched boxes | ≥ 0.60 | [PENDING] |
| Adjudicated disagreements | all resolved | [PENDING] |

**Report the per-class kappa even where it fails the gate.** A class with kappa
0.55, honestly reported, is more useful than one silently shipped at an
unmeasured 0.55 — and the per-class kappa is itself a scientific result: it
measures how intrinsically ambiguous each class is. We expect the contextually
defined classes (`suspicious_behavior`, `intrusion`) to score lower than the
appearance-defined ones (`fire`, `fall`), which would corroborate the central
finding of the accompanying paper.

---

## 4. Preprocessing

- Clips cut with `ffmpeg` (`-an`: source audio discarded — irrelevant, and
  corrupt in some corpora).
- Frames extracted as JPEG (quality 2), 1-indexed.
- Annotation in CVAT; export **COCO 1.0** (never YOLO: the YOLO format cannot
  carry the compositional attributes).
- Converted with `psid8/scripts/coco_to_yolo.py`, which preserves the attributes
  in per-frame `.attrs.json` sidecars.
- Keyframe annotation every 10 frames with linear interpolation between
  keyframes; a keyframe is forced at any sharp change of posture or direction.

---

## 5. Splits

Built with `psid8/scripts/build_splits.py --seed 0`, then frozen by SHA-256 with
`integrity_check.py` **before any model is trained**.

- **Camera-disjoint**: no camera appears in more than one split. This is the
  guarantee that a reported number means generalization and not memorization of
  a viewpoint.
- **Class-covering**: every class appears in every split.
- Scenario-stratified where the number of cameras permits; when it does not, the
  builder falls back to global camera-level allocation and **records that fact**
  in `splits.json` (`"stratification": "global_fallback"`). Declare it in any
  paper that uses the split.

Freeze hashes: [PENDING].

---

## 6. Uses

**Intended.** Research on spatiotemporal incident detection, compositional event
representation, and the evaluation of temporal reasoning under realistic data
constraints. The accompanying toolkit (`sentry/`, `psid8/`) implements the
protocol.

**Out of scope / discouraged.**
- Operational deployment for surveillance of identifiable individuals. This
  corpus is for research; it is not validated for, and must not be used as, the
  basis of an operational system that makes decisions about people.
- Person re-identification, face recognition, or any identity-linking task. The
  annotations deliberately carry no identity information.
- Training systems that infer intent or criminality from appearance,
  demographics, or dress. `suspicious_behavior` is defined by four enumerated
  movement patterns precisely to prevent this; any use that redefines it by
  appearance violates the intended use.

**Known biases.** The source corpora carry their own geographic, demographic and
scene biases, which propagate into PSID-8. [PENDING — characterize what can be
characterized, and state plainly what cannot.] Do not claim a representativeness
you have not measured.

---

## 7. Ethics and privacy

- The corpus contains **real surveillance footage of real people** who did not
  consent to research use. This is why we distribute **annotations and
  extraction recipes, not video**: users must obtain the source corpora under
  their original licenses. [Confirm this is compatible with each source's terms:
  PENDING.]
- No identity annotation of any kind is collected or distributed.
- Ethics review: [PENDING — institutional approval reference, or a statement of
  why none was required.]
- Faces are not blurred in the source corpora and we do not modify the frames.
  Users redistributing derived material must consider this.

---

## 8. Distribution

- **Annotations + toolkit**: released under [PENDING: CC BY 4.0 is the
  recommended license for the annotations; MIT already covers the code].
- **Video**: not redistributed. `curate_clips.py` reproduces the exact clip set
  from the source corpora, and each clip's `meta.json` records the source file's
  SHA-256 prefix so users can verify they cut the same material.
- **DOI**: minted via Zenodo. The dataset gets its **own deposit**, separate from
  the code deposit (different license, different versioning cadence). [PENDING]

---

## 9. Maintenance

- Maintainer: [PENDING]
- Versioning: semantic (`v1.0`, `v1.1`, …). Any change to labels or splits bumps
  the version and is recorded in the changelog; the frozen split hashes of each
  version are published so old results remain reproducible.
- Erratum policy: label errors reported by users are adjudicated with the same
  process as the original disagreements, and corrections ship in the next
  version with a diff.

---

## Release checklist

- [ ] Calibration passed (`calibration_report.json`, all classes ≥ 0.70 kappa, or
      failures explicitly declared)
- [ ] 20% double-annotated; agreement computed and reported per class
- [ ] All adjudications resolved and logged
- [ ] Hard negatives collected and tagged
- [ ] Zones annotated for every scene carrying an `intrusion` label
- [ ] Splits built, camera disjunction verified, hashes frozen
- [ ] `dataset_stats.py` run; every `[PENDING]` in this datasheet filled
- [ ] Licenses of every source corpus verified as compatible with distributing
      derived annotations
- [ ] Ethics statement written; intended-use and out-of-scope sections final
- [ ] Zenodo deposit created (dataset, separate from code); DOI minted
- [ ] The dataset paper reports the per-class kappa, including the classes that
      failed their gate
