# PSID-8 Phase 0: Annotator Calibration Protocol

**Do not begin mass annotation before this phase passes.** Every hour spent here
saves ten in re-annotation, and it is the difference between a benchmark whose
labels mean something and a benchmark that measures annotator noise.

The purpose is not to *test* the annotators. It is to **repair the guide**. Low
agreement almost never means the annotators are careless; it means a rule is
ambiguous, and the fix belongs in `VIDEO_ANNOTATION_GUIDE.md`, not in a
reprimand.

---

## Who

Minimum: **two annotators plus one adjudicator**. A single-annotator corpus
carries a defect that no reviewer of a benchmark paper will accept, and it
cannot report the per-class kappa that is itself one of this benchmark's
results.

The adjudicator should be the person who owns the guide (i.e. you), because the
adjudication decisions must flow back into it.

---

## The calibration set

**30 clips**, chosen deliberately — not sampled at random:

| Count | What | Why |
|---|---|---|
| 8 | one clear positive per class | establishes the baseline for each class |
| 10 | **hard cases**: near-boundary events | this is where disagreement lives |
| 8 | **hard negatives** (§7 of the guide) | tests whether the negatives hold |
| 4 | multi-class / co-occurring events | tests event separation and `event_id` |

The 10 hard cases must include, at minimum: a person lying down with no visible
transition (fall?); smoke with no flame (fire?); someone standing near a door for
a long time (loitering, or waiting?); an object put down and picked up after ~40 s
(abandonment?); rough play (crime, or horseplay?).

Freeze this set. It is reused in every calibration round, so rounds are
comparable.

---

## The rounds

### Round 1 — blind
Both annotators annotate all 30 clips **independently**, with no discussion.
Compute:

```
python psid8/scripts/agreement.py annotatorA.json annotatorB.json
```

This reports Cohen's kappa per class and the mean IoU of matched boxes.

**Expected outcome: some classes fail.** This is normal and is the point of the
exercise. In the pilot, `suspicious_behavior` and `intrusion` are the classes
most likely to fail, for the reason the main paper already documented: they are
contextually rather than visually defined.

### Round 2 — adjudication and guide repair
For every disagreement:
1. The adjudicator decides the correct label.
2. **The disagreement is classified**:
   - *rule gap* — the guide does not cover this case → **write a rule**;
   - *rule ambiguity* — the guide covers it but can be read two ways → **rewrite
     the rule**;
   - *annotator error* — the guide was clear and one annotator misread it →
     re-train on that rule.
3. Every decision goes into `adjudications.csv` with its classification.

**If most disagreements are rule gaps or ambiguities, the annotators are fine
and the guide is not.** Fix the guide, then repeat Round 1 on the same 30 clips.

### Round 3 — confirmation
Re-run the blind round on the frozen calibration set with the repaired guide.

**Gate to proceed to mass annotation:**
- kappa ≥ 0.70 on **every class that will be annotated**;
- mean box IoU ≥ 0.60;
- no unresolved cases in `adjudications.csv`.

A class that cannot reach 0.70 after two rounds of guide repair is telling you
something real: it is **intrinsically ambiguous**. You then have two honest
options, and both are publishable:

- **Narrow the definition** until it becomes reliable (e.g. `suspicious_behavior`
  restricted to the four enumerated patterns, which is exactly why the guide
  enumerates them), then re-calibrate; or
- **Ship the class with its kappa reported** as a known limitation, and *say so*
  in the dataset paper. A class with kappa 0.55 that is honestly reported is far
  more useful to the community than one silently shipped at an unmeasured 0.55.

Do not quietly proceed with a failing class. The number will surface later, in
someone else's error analysis, and it will look like concealment.

---

## What to record (this is a result, not bookkeeping)

Produce `calibration_report.json`:

```json
{
  "rounds": [
    {"round": 1, "kappa": {"fall": 0.86, "intrusion": 0.41, "...": "..."},
     "mean_box_iou": 0.71, "n_disagreements": 37},
    {"round": 3, "kappa": {"fall": 0.91, "intrusion": 0.74, "...": "..."},
     "mean_box_iou": 0.78, "n_disagreements": 9}
  ],
  "disagreement_causes": {"rule_gap": 21, "rule_ambiguity": 12, "annotator_error": 4},
  "guide_version_before": "1.0", "guide_version_after": "1.2",
  "gate_passed": true
}
```

The **improvement between rounds** is evidence that the guide, not the
annotators, was the bottleneck — and the **final per-class kappa** is a headline
number of the dataset paper. Report both.

---

## Time budget

| Step | Effort |
|---|---|
| Select and cut the 30 calibration clips | 3–4 h (adjudicator) |
| Round 1 annotation | ~4 h per annotator |
| Adjudication + guide repair | 4–6 h (adjudicator) |
| Round 3 annotation | ~3 h per annotator |
| Report | 1 h |

**Roughly one week, part-time.** It is the cheapest week in the entire project
and the one that determines whether the other seven are worth anything.
