# PSID-8 Video Annotation Guide (v1.0)

This guide exists for one purpose: **two annotators looking at the same clip must
produce the same annotation.** Every rule below was written to remove a specific
judgement call. When you disagree with a rule, do not improvise — log the case
(§8) and it will be adjudicated and folded back into the guide.

Read §1–§3 before your first clip. Keep §4 open while annotating.

---

## 1. What you are annotating

For every incident you see, you produce:

1. **A bounding box per keyframe** around the entity that *constitutes* the
   event (see §2 for who that is), from the event's start to its end.
2. **Four compositional attributes** on the event: `object`, `action`,
   `environment`, `context` (closed vocabularies — pick from the list, never
   type free text).
3. **An `event_id`** that stays the same for the whole event, so the boxes link
   into one temporal track.

You do **not** annotate every frame. You annotate **keyframes every 10 frames**
(and at every sharp change of direction or posture); CVAT interpolates between
them. If the interpolated box drifts off the subject, add a keyframe there.

---

## 2. The single hardest question: what is the box around?

**Rule: the box encloses the entity whose state defines the event.**

| Class | The box is around | NOT around |
|---|---|---|
| fall | the falling person, from loss of balance to rest | the floor, the obstacle |
| fire | the visible flame/smoke region | the object presumed to be burning |
| intrusion | the intruding person | the fence, door or window |
| crime | the aggressor AND the victim (two boxes, same event_id) | bystanders |
| accident | each vehicle/person directly involved | the road, the crowd |
| vandalism | the person causing damage, and the damaged object if visible | undamaged surroundings |
| suspicious_object | the object itself | the person who left it (that is a separate event, if any) |
| suspicious_behavior | the person exhibiting the pattern | the area they are loitering in |

When two entities are both constitutive (crime: aggressor + victim; accident:
two cars), give them **separate boxes with the same `event_id`**.

---

## 3. Temporal boundaries: when does the event start and end?

This is where annotators disagree most. The rules are deliberately mechanical.

| Class | Starts at the frame where… | Ends at the frame where… |
|---|---|---|
| **fall** | balance is visibly lost (the body begins its uncontrolled descent) | the body comes to rest on the ground |
| **fire** | flame or smoke first becomes visible | it leaves the frame or is extinguished |
| **intrusion** | any part of the body crosses the declared zone boundary (§5) | the person leaves the zone or the clip ends |
| **crime** | the first hostile physical contact or the weapon becomes visible | the parties separate or the aggressor flees |
| **accident** | first contact/impact | the scene stops moving |
| **vandalism** | the first damaging action (the swing, the spray, the kick) | the damaging action stops |
| **suspicious_object** | the carrier releases the object and moves away | the object is retrieved, or the clip ends |
| **suspicious_behavior** | the *pattern* becomes identifiable (see §4) | the person leaves or the pattern stops |

**If the event has already begun when the clip starts**, annotate from frame 1
and set `truncated_start = true`. Same for `truncated_end`. Do not guess what
happened off-camera.

---

## 4. Class definitions and their hard cases

Each class lists what it **is**, and — more importantly — what looks like it but
**is not**. The negatives are not optional reading: they are what the benchmark
is designed to measure.

### fall
**Is:** an unintentional transition from upright/seated to the ground.
**Is NOT:**
- a person **already lying down** with no observed transition → background;
- sitting down, lying down deliberately, kneeling → background;
- a controlled descent (crouching, exercising) → background;
- a fall that is part of a fight → that is `crime` (the fall is a consequence).
**Hard case:** person stumbles and recovers without reaching the ground →
**background**. The definition requires rest on the ground.

### fire
**Is:** visible uncontrolled flame or smoke.
**Is NOT:**
- a lit cigarette, candle, stove, controlled cooking fire → background;
- steam, fog, dust, exhaust → background (log it as a hard negative);
- a fire visible only on a screen/monitor inside the scene → background.
**Hard case:** thick smoke with no visible flame → **annotate as fire**; the
`object` attribute distinguishes flame from smoke.

### intrusion
**Is:** a person crossing into the declared restricted zone (§5), in any posture
— walking, climbing, crawling, jumping.
**Is NOT:**
- a person walking in a public area with no declared zone → background;
- a person inside a building whose access rights are unknown to us → **background**;
- an authorized entry (door opened normally, in working hours, no forcing) →
  background.
**Hard case:** this class is meaningless without a zone. **If the scene has no
declared restricted zone, the clip cannot carry an intrusion label.** Flag it
for zone annotation (§5) or discard it.

### crime
**Is:** physical assault, robbery, theft in progress, threat with a visible
weapon.
**Is NOT:**
- shouting, arguing, gesticulating with no physical contact → `suspicious_behavior`;
- a fall during a fight → part of the `crime` event, not a separate `fall`;
- police restraining someone → background (log the case; it is genuinely
  ambiguous and we do not label it).
**Hard case:** rough play/horseplay between friends → **background**. If you
cannot tell play from assault, log it — do not guess.

### accident
**Is:** an unintentional collision/impact involving vehicles and/or people.
**Is NOT:**
- a near-miss with no contact → background;
- a deliberate ramming → `crime`;
- a vehicle simply braking hard → background.

### vandalism
**Is:** intentional damage to property — breaking, smashing, kicking, spraying.
**Is NOT:**
- graffiti **already on a wall**, with nobody acting → background (the event is
  the *act*, not the trace);
- accidental damage → `accident`;
- damage during a robbery → part of the `crime` event.

### suspicious_object
**Is:** a portable object left without a visible carrier for **≥ 30 seconds**
in a circulation area.
**Is NOT:**
- an object a person is still next to, or returns to within 30 s → background;
- fixed street furniture, bins, signage → background;
- luggage next to a seated person → background.
**Hard case:** the carrier leaves the frame but the object is against a wall and
clearly stationary — the 30-second clock starts when the carrier is **no longer
visible next to the object**.

### suspicious_behavior
**Is:** a movement pattern inconsistent with normal use of the site. It requires
a **pattern**, and the pattern must be one of these four:
1. **loitering** — remaining in the same small area for ≥ 60 s with no apparent
   purpose;
2. **repeated passes** — passing the same point ≥ 2 times within 2 minutes;
3. **access testing** — trying doors, windows, handles, locks;
4. **following** — tracking another person's path at a short distance.
**Is NOT:**
- a single pass, however unusual the person looks → background;
- waiting for a bus, a person, a shop to open → background (log as hard negative);
- running for a bus, being late, hurrying → background;
- someone standing still using their phone → background.
**This is the most subjective class in the benchmark.** When in doubt, do NOT
label. A missed suspicious behaviour costs us recall; an invented one poisons
the class.

---

## 5. Zones (required before annotating intrusion)

For every scene that contains a restricted area, draw **one polygon per zone** on
a reference frame, and give it:
- `zone_id`, `zone_type` (perimeter, controlled_access, restricted_area),
- `active_hours` if the restriction is time-dependent (e.g. "after 22:00").

Intrusion is then defined mechanically: *any part of a person's box crossing the
polygon during its active hours*. Without a zone, no intrusion label — this is
what makes the class objective rather than a guess about who belongs where.

---

## 6. Compositional attributes

Every event gets all four. Pick from the closed vocabulary in `schema.json`:

- **object** — the entity: `person`, `vehicle`, `bag`, `flame`, `smoke`, …
- **action** — the verb, class-specific: `person_collapsed`, `fence_climbing`,
  `loitering`, `spray_painting`, …
- **environment** — where: `public_street`, `perimeter_fence`, `indoor_corridor`,
  `controlled_access`, …
- **context** — what makes it an incident: `abnormal` (default for a real event),
  `normal` (used on hard negatives).

If no vocabulary value fits, **log the case (§8)**. Do not invent a value: a new
value must be added to the schema deliberately, or the vocabulary stops being
closed and the benchmark stops being comparable.

---

## 7. Hard negatives (annotate these deliberately)

A clip with **no** incident is not automatically a boring clip. We deliberately
collect and tag these:

| Tag | Example | Why it matters |
|---|---|---|
| `lying_no_transition` | a person already on the ground | separates fall from posture |
| `benign_smoke` | barbecue, steam, exhaust | separates fire from smoke-like |
| `authorized_entry` | someone opening a door normally | separates intrusion from access |
| `waiting` | at a bus stop, for a friend | separates loitering from waiting |
| `brief_object` | bag put down and picked up in 10 s | separates abandonment from pause |
| `horseplay` | friends shoving playfully | separates crime from play |
| `running_benign` | running for a bus, jogging | separates flight from hurry |

Tag them in the clip metadata with `hard_negative: [tag]`. These clips carry
**no event annotation** — they are negatives — but they are the most valuable
negatives in the corpus.

---

## 8. When you are unsure: the log, not the guess

Open `adjudications.csv` and add a row:
`clip_id, frame_range, what_you_saw, candidate_classes, why_you_are_unsure`.

Then move on. A third annotator adjudicates in batch, the decision is recorded,
and — if the case is general — the rule enters this guide.

**Guessing is worse than skipping.** A guessed label enters the ground truth and
no downstream metric can ever detect it. A logged case gets resolved once and
improves the guide for everyone.

---

## 9. Quality gates (what the corpus must pass before release)

- **20% of clips are double-annotated** by two annotators independently.
- **Cohen's kappa ≥ 0.70 per class** on the double-annotated sample.
- **Mean IoU ≥ 0.60** on matched boxes.
- Disagreements adjudicated by a third annotator; decisions logged.

Run `python psid8/scripts/agreement.py A.json B.json` to check. **A class that
fails its gate is not silently shipped** — it is either re-annotated after the
guide is fixed, or released with its kappa reported as a known limitation. The
per-class kappa is itself a result: it measures how intrinsically ambiguous each
class is, and we report it.

---

## 10. Export

CVAT → **COCO 1.0** (never YOLO: the YOLO format cannot carry the compositional
attributes and they would be silently lost). Then:

```
python psid8/scripts/coco_to_yolo.py instances_default.json images/ out/
python psid8/scripts/build_splits.py manifest.json --out splits.json --seed 0
python psid8/scripts/integrity_check.py manifest.json splits.json
```
